package com.FitnessHub;

public class User {
	
	private String Groeße;
	private String Gewicht;
	private String koerpertyp;
	private String Geschlecht;
	public String getGroeße() {
		return Groeße;
	}
	public void setGroeße(String groeße) {
		Groeße = groeße;
	}
	public String getGewicht() {
		return Gewicht;
	}
	public void setGewicht(String gewicht) {
		Gewicht = gewicht;
	}
	public String getKoerpertyp() {
		return koerpertyp;
	}
	public void setKoerpertyp(String koerpertyp) {
		this.koerpertyp = koerpertyp;
	}
	public String getGeschlecht() {
		return Geschlecht;
	}
	public void setGeschlecht(String geschlecht) {
		Geschlecht = geschlecht;
	}
	@Override
	public String toString() {
		return "User [Groeße=" + Groeße + ", Gewicht=" + Gewicht + ", koerpertyp=" + koerpertyp + ", Geschlecht="
				+ Geschlecht + "]";
	}
	
	
	

}
